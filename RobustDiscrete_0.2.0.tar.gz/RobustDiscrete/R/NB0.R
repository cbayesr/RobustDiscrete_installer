dNB0=function (x, mu = 1, sigma = 1,log = FALSE) {
  nu=0
  if (any(mu <= 0))
    stop(paste("mu must be greater than 0 ", "\n", ""))
  if (any(sigma <= 0))
    stop(paste("sigma must be greater than 0 ", "\n", ""))
  if (any(x < 0))
    stop(paste("x must be >=0", "\n", ""))
  ly <- max(length(x), length(mu), length(sigma))
  x <- rep(x, length = ly)
  mu <- rep(mu, length = ly)
  sigma <- rep(sigma, length = ly)
  mu1 <- mu
  sigma1 <- sigma * mu^(nu - 2)
  if (length(sigma1) > 1)
    fy <- ifelse(sigma1 > 1e-04, dnbinom(x, size = 1/sigma1,
                                         mu = mu1, log = log), dPO(x, mu = mu1, log = log))
  else fy <- if (sigma1 < 1e-04)
    dPO(x, mu = mu1, log = log)
  else dnbinom(x, size = 1/sigma1, mu = mu1, log = log)
  fy
}

pNB0=function (q, mu = 1, sigma = 1, lower.tail = TRUE, log.p = FALSE) {
  nu = 0
  if (any(mu <= 0))
    stop(paste("mu must be greater than 0 ", "\n", ""))
  if (any(sigma <= 0))
    stop(paste("sigma must be greater than 0 ", "\n", ""))
  if (any(q < 0))
    stop(paste("q must be >=0", "\n", ""))
  ly <- max(length(q), length(mu), length(sigma))
  q <- rep(q, length = ly)
  mu <- rep(mu, length = ly)
  sigma <- rep(sigma, length = ly)
  mu1 <- mu
  sigma1 <- sigma * mu^(nu - 2)
  if (length(sigma1) > 1)
    cdf <- ifelse(sigma1 > 1e-04, pnbinom(q, size = 1/sigma1,
                                          mu = mu1, lower.tail = lower.tail, log.p = log.p),
                  ppois(q, lambda = mu1, lower.tail = lower.tail, log.p = log.p))
  else cdf <- if (sigma1 < 1e-04)
    ppois(q, lambda = mu1, lower.tail = lower.tail, log.p = log.p)
  else pnbinom(q, size = 1/sigma1, mu = mu1, lower.tail = lower.tail,
               log.p = log.p)
  cdf
}

NB0=function (mu.link = "log", sigma.link = "log") {
  mstats <- checklink("mu.link", "NB Family", substitute(mu.link),
                      c("inverse", "log", "identity"))
  dstats <- checklink("sigma.link", "NB Family", substitute(sigma.link),
                      c("inverse", "log", "identity"))
  structure(list(family = c("NB0", "NB0"), parameters =
                   list(mu = TRUE,sigma = TRUE), nopar = 2, type = "Discrete",
                 mu.link = as.character(substitute(mu.link)),
                 sigma.link = as.character(substitute(sigma.link)),
                 mu.linkfun = mstats$linkfun,
                 sigma.linkfun = dstats$linkfun,
                 mu.linkinv = mstats$linkinv,
                 sigma.linkinv = dstats$linkinv,
                 mu.dr = mstats$mu.eta,
                 sigma.dr = dstats$mu.eta,
                 dldm = function(y, mu, sigma) {
                   nu=0
                   mu1 <- mu
                   sigma1 <- sigma * (mu^(nu - 2))
                   dldm1 <- (y - mu1)/(mu1 * (1 + mu1 * sigma1))
                   dldd1 <- -((1/sigma1)^2) * (digamma(y + (1/sigma1)) -
                                                 digamma(1/sigma1) - log(1 + mu1 * sigma1) - (y -
                                                                                                mu1) * sigma1/(1 + mu1 * sigma1))
                   dldm <- dldm1 + dldd1 * sigma * (nu - 2) * (mu^(nu -
                                                                     3))
                   dldm
                 }, d2ldm2 = function(y, mu, sigma) {
                   nu=0
                   mu1 <- mu
                   sigma1 <- sigma * (mu^(nu - 2))
                   dldm1 <- (y - mu1)/(mu1 * (1 + mu1 * sigma1))
                   dldd1 <- -((1/sigma1)^2) * (digamma(y + (1/sigma1)) -
                                                 digamma(1/sigma1) - log(1 + mu1 * sigma1) - (y -
                                                                                                mu1) * sigma1/(1 + mu1 * sigma1))
                   dldm <- dldm1 + dldd1 * sigma * (nu - 2) * (mu^(nu -
                                                                     3))
                   d2ldm2 <- -dldm^2
                   d2ldm2
                 }, dldd = function(y, mu, sigma) {
                   nu=0
                   mu1 <- mu
                   sigma1 <- sigma * (mu^(nu - 2))
                   dldd1 <- -((1/sigma1)^2) * (digamma(y + (1/sigma1)) -
                                                 digamma(1/sigma1) - log(1 + mu1 * sigma1) - (y -
                                                                                                mu1) * sigma1/(1 + mu1 * sigma1))
                   dldd <- dldd1 * (mu^(nu - 2))
                 }, d2ldd2 = function(y, mu, sigma) {
                   nu=0
                   mu1 <- mu
                   sigma1 <- sigma * (mu^(nu - 2))
                   dldd1 <- -((1/sigma1)^2) * (digamma(y + (1/sigma1)) -
                                                 digamma(1/sigma1) - log(1 + mu1 * sigma1) - (y -
                                                                                                mu1) * sigma1/(1 + mu1 * sigma1))
                   dldd <- dldd1 * (mu^(nu - 2))
                   d2ldd2 <- -dldd^2
                 },  d2ldmdd = function(y) rep(0, length(y)),
                 G.dev.incr = function(y, mu, sigma, ...) -2 * dNB0(y,mu, sigma, log = TRUE), rqres = expression(rqres(pfun = "pNB0",
                                                                                                                       type = "Continuous", y = y, mu = mu, sigma = sigma)), mu.initial = expression(mu <- (y + mean(y))/2),
                 sigma.initial = expression(sigma <- rep(max(((var(y) -
                                                                 mean(y))/(mean(y)^2)), 0.1), length(y))),
                 mu.valid = function(mu) all(mu > 0), sigma.valid = function(sigma) all(sigma >
                                                                                          0), y.valid = function(y) all(y >=
                                                                                                                          0), mean = function(mu, sigma, nu) mu, variance = function(mu,
                                                                                                                                                                                     sigma, nu) mu + sigma * mu^(nu)), class = c("gamlss.family",
                                                                                                                                                                                                                                 "family"))
}

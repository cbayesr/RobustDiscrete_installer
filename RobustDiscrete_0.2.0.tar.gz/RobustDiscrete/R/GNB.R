dGNB_scalar = function(y,mu,phi,nu,k){
  r=0
  if(nu<0.001){
    dnbinom(y,mu**(2-k)/phi,(mu**(1-k))/(phi+mu**(1-k)))
  }
  else{
    shape = phi**(2-r)/nu
    scale = nu/phi**(1-r)
    if(shape<30){
      a=integrate(cpp_joint_gnb,-Inf,Inf,y=y,mu=mu,phi=phi,nu=nu,k=k,
                  stop.on.error = FALSE,rel.tol = 1e-8)
      if(a$message=="OK"){
        return(a$value)
      }else{
        a=pracma::quadinf(cpp_joint_gnb,-Inf,Inf,y=y,mu=mu,phi=phi,nu=nu,k=k)$Q
        return(a)
      }
    }else{
      lb = max(0,shape*scale-6*sqrt(shape)*scale)
      ub = shape*scale+6*sqrt(shape)*scale
      lb = log(lb)
      ub = log(ub)
      a=integrate(cpp_joint_gnb,lb,ub,y=y,mu=mu,phi=phi,nu=nu,k=k,
                  stop.on.error = FALSE)
      if(a$message=="OK"){
        return(a$value)
      }else{
        a=pracma::quadinf(cpp_joint_gnb,lb,ub,y=y,mu=mu,phi=phi,nu=nu,k=k)$Q
        return(a)
      }
    }
  }
}

dGNB_ = Vectorize(dGNB_scalar)

pGNB_scalar = function(y,mu,phi,nu,k){
  sum(dGNB_(0:y,mu,phi,nu,k))
}

pGNB_ = Vectorize(pGNB_scalar)

####################################################
# GNB 1                                            #
####################################################

dGNB1=
  function (x, mu = 1, sigma = 1, nu = 1, log = FALSE){
    tau=1
    if (any(mu <= 0))
      stop(paste("mu must be greater than 0", "\n", ""))
    if (any(sigma <= 0) )
      stop(paste("sigma must be greater than 0", "\n", ""))
    if (any(nu <= 0) )
      stop(paste("nu must be greater than 0", "\n", ""))
    if (any(tau < 0) )
      stop(paste("tau must be greater than 0", "\n", ""))
    if (any(x < 0))
      stop(paste("x must be 0 or greater than 0", "\n", ""))
    ly <- max(length(x), length(mu), length(sigma), length(nu),length(tau))
    x <- rep(x, length = ly)
    sigma <- rep(sigma, length = ly)
    mu <- rep(mu, length = ly)
    nu <- rep(nu, length = ly)
    tau <- rep(tau, length = ly)
    logfy <- log(dGNB_(x,mu,sigma,nu,tau))
    if (log == FALSE)
      fy <- exp(logfy)
    else fy <- logfy
    fy
  }



pGNB1=
  function (q, mu = 1, sigma = 1, nu = 1,  lower.tail = TRUE,
            log.p = FALSE){
    tau=1
    if (any(mu <= 0))
      stop(paste("mu must be greater than 0", "\n", ""))
    if (any(sigma <= 0) )
      stop(paste("sigma must be greater than 0", "\n", ""))
    if (any(nu <= 0) )
      stop(paste("nu must be greater than 0", "\n", ""))
    if (any(tau < 0) )
      stop(paste("tau must be greater than 0", "\n", ""))
    if (any(q < 0))
      stop(paste("q must be 0 greater than 0", "\n", ""))
    ly <- max(length(q), length(mu), length(sigma), length(nu),length(tau))
    q <- rep(q, length = ly)
    sigma <- rep(sigma, length = ly)
    mu <- rep(mu, length = ly)
    nu <- rep(nu, length = ly)
    tau <- rep(tau, length = ly)
    cdf <- rep(0, ly)
    cdf <- pGNB_(q,mu,sigma,nu,tau)
    cdf <- ifelse(cdf > 1L, 1L, cdf)
    if (lower.tail == TRUE)
      cdf <- cdf
    else cdf <- 1 - cdf
    if (log.p == FALSE)
      cdf <- cdf
    else cdf <- log(cdf)
    cdf
  }

GNB1=
  function (mu.link = "log", sigma.link = "log", nu.link = "log"){
    mstats <- checklink("mu.link", "GNB1", substitute(mu.link),
                        c("1/mu^2", "log", "identity"))
    dstats <- checklink("sigma.link", "GNB1", substitute(sigma.link),
                        c("1/mu^2", "log", "identity"))
    vstats <- checklink("nu.link", "GNB1", substitute(nu.link),
                        c("1/mu^2", "log", "identity"))
    structure(list(family = c("NBF", "Negative-Binomial-Gamma 1"),
                   parameters = list(mu = TRUE, sigma = TRUE, nu = TRUE),
                   nopar = 3,
                   type = "Discrete",

                   mu.link    = as.character(substitute(mu.link)),
                   sigma.link = as.character(substitute(sigma.link)),
                   nu.link    = as.character(substitute(nu.link)),

                   mu.linkfun    = mstats$linkfun,
                   sigma.linkfun = dstats$linkfun,
                   nu.linkfun    = vstats$linkfun,

                   mu.linkinv    = mstats$linkinv,
                   sigma.linkinv = dstats$linkinv,
                   nu.linkinv    = vstats$linkinv,

                   mu.dr    = mstats$mu.eta,
                   sigma.dr = dstats$mu.eta,
                   nu.dr    = vstats$mu.eta,

                   #----------------------------------------#
                   # first numerical derivatives            #
                   #----------------------------------------#

                   dldm = function(y, mu, sigma, nu) {
                     lpdf<-function(t,x,sigma,nu){dGNB1(t,x,sigma,nu,log=TRUE)}
                     dldm<-grad(func=lpdf,t=y,x=mu,sigma=sigma,nu=nu,method='simple')
                     dldm
                   },

                   dldd = function(y, mu, sigma, nu) {
                     lpdf<-function(t,mu,x,nu){dGNB1(t,mu,x,nu,log=TRUE)}
                     dldd<-grad(func=lpdf,t=y,mu=mu,x=sigma,nu=nu,method='simple')
                     dldd
                   },

                   dldv = function(y, mu, sigma, nu) {
                     lpdf<-function(t,mu,sigma,x){dGNB1(t,mu,sigma,x,log=TRUE)}
                     dldv<-grad(func=lpdf,t=y,mu=mu,sigma=sigma,x=nu,method='simple')
                     dldv
                   },

                   #----------------------------------------#
                   # second numerical derivatives           #
                   #----------------------------------------#

                   d2ldm2 = function(y, mu, sigma, nu) {
                     lpdf<-function(t,x,sigma,nu){dGNB1(t,x,sigma,nu,log=TRUE)}
                     dldm<-grad(func=lpdf,t=y,x=mu,sigma=sigma,nu=nu,method='simple')
                     d2ldm2 <- -dldm * dldm
                     d2ldm2 <- ifelse(d2ldm2 < -1e-15, d2ldm2,-1e-15)
                     d2ldm2
                   },

                   d2ldd2 = function(y, mu, sigma, nu) {
                     lpdf<-function(t,mu,x,nu){dGNB1(t,mu,x,nu,log=TRUE)}
                     dldd<-grad(func=lpdf,t=y,mu=mu,x=sigma,nu=nu,method='simple')
                     d2ldd2 <- -dldd * dldd
                     d2ldd2 <- ifelse(d2ldd2 < -1e-15, d2ldd2,-1e-15)
                     d2ldd2
                   },

                   d2ldv2 = function(y, mu, sigma, nu) {
                     lpdf<-function(t,mu,sigma,x){dGNB1(t,mu,sigma,x,log=TRUE)}
                     dldv<-grad(func=lpdf,t=y,mu=mu,sigma=sigma,x=nu,method='simple')
                     d2ldv2 <- -dldv * dldv
                     d2ldv2 <- ifelse(d2ldv2 < -1e-15, d2ldv2,-1e-15)
                     d2ldv2
                   },

                   #-----------------------------#
                   # cross numerical derivatives #
                   #-----------------------------#

                   d2ldmdd = function(y, mu, sigma, nu) {
                     lpdf<-function(t,x,sigma,nu){dGNB1(t,x,sigma,nu,log=TRUE)}
                     dldm<-grad(func=lpdf,t=y,x=mu,sigma=sigma,nu=nu,method='simple')
                     lpdf<-function(t,mu,x,nu){dGNB1(t,mu,x,nu,log=TRUE)}
                     dldd<-grad(func=lpdf,t=y,mu=mu,x=sigma,nu=nu,method='simple')
                     d2ldmdd <- -dldm * dldd
                     d2ldmdd <- ifelse(is.na(d2ldmdd)==TRUE,0,d2ldmdd)
                     # d2ldmdd <- ifelse(d2ldmdd < -1e-15, d2ldmdd,-1e-15)
                     d2ldmdd
                   },

                   d2ldmdv = function(y, mu, sigma, nu) {
                     lpdf<-function(t,x,sigma,nu){dGNB1(t,x,sigma,nu,log=TRUE)}
                     dldm<-grad(func=lpdf,t=y,x=mu,sigma=sigma,nu=nu,method='simple')
                     lpdf<-function(t,mu,sigma,x){dGNB1(t,mu,sigma,x,log=TRUE)}
                     dldv<-grad(func=lpdf,t=y,mu=mu,sigma=sigma,x=nu,method='simple')
                     d2ldmdv <- -dldm * dldv
                     d2ldmdv <- ifelse(is.na(d2ldmdv)==TRUE,0,d2ldmdv)
                     # d2ldmdv <- ifelse(d2ldmdv < -1e-15, d2ldmdv,-1e-15)
                     d2ldmdv
                   },

                   d2ldddv = function(y, mu, sigma, nu) {
                     lpdf<-function(t,mu,x,nu){dGNB1(t,mu,x,nu,log=TRUE)}
                     dldd<-grad(func=lpdf,t=y,mu=mu,x=sigma,nu=nu,method='simple')
                     lpdf<-function(t,mu,sigma,x){dGNB1(t,mu,sigma,x,log=TRUE)}
                     dldv<-grad(func=lpdf,t=y,mu=mu,sigma=sigma,x=nu,method='simple')
                     d2ldddv <- -dldd * dldv
                     d2ldddv <- ifelse(is.na(d2ldddv)==TRUE,0,d2ldddv)
                     # d2ldddv <- ifelse(d2ldddv < -1e-15, d2ldddv,-1e-15)
                     d2ldddv
                   },

                   G.dev.incr = function(y, mu, sigma, nu, ...){
                     -2 * dGNB1(y, mu, sigma, nu, log = TRUE)}
                   ,

                   rqres = expression(rqres(pfun = "pGNB1",type = "Discrete",
                                            ymin = 0, y = y, mu = mu, sigma = sigma,
                                            nu = nu)),

                   mu.initial = expression(mu <- (y + mean(y))/2),

                   sigma.initial = expression(sigma <- rep(max(((var(y) - mean(y))/(mean(y)^2)), 0.1), length(y))),

                   nu.initial = expression(nu <- rep(1,length(y))),

                   tau.initial = expression(tau <- rep(1,length(y))),

                   mu.valid = function(mu) all(mu > 0),

                   sigma.valid = function(sigma) all(sigma > 0),

                   nu.valid = function(nu) all(nu > 0 ),

                   y.valid = function(y) all(y >= 0)
    ),

    class = c("gamlss.family","family"))
  }

####################################################
# GNB 2                                            #
####################################################

dGNB2=
  function (x, mu = 1, sigma = 1, nu = 1, log = FALSE){
    tau=2
    if (any(mu <= 0))
      stop(paste("mu must be greater than 0", "\n", ""))
    if (any(sigma <= 0) )
      stop(paste("sigma must be greater than 0", "\n", ""))
    if (any(nu <= 0) )
      stop(paste("nu must be greater than 0", "\n", ""))
    if (any(tau < 0) )
      stop(paste("tau must be greater than 0", "\n", ""))
    if (any(x < 0))
      stop(paste("x must be 0 or greater than 0", "\n", ""))
    ly <- max(length(x), length(mu), length(sigma), length(nu),length(tau))
    x <- rep(x, length = ly)
    sigma <- rep(sigma, length = ly)
    mu <- rep(mu, length = ly)
    nu <- rep(nu, length = ly)
    tau <- rep(tau, length = ly)
    logfy <- log(dGNB_(x,mu,sigma,nu,tau))
    if (log == FALSE)
      fy <- exp(logfy)
    else fy <- logfy
    fy
  }



pGNB2=
  function (q, mu = 1, sigma = 1, nu = 1,  lower.tail = TRUE,
            log.p = FALSE){
    tau=2
    if (any(mu <= 0))
      stop(paste("mu must be greater than 0", "\n", ""))
    if (any(sigma <= 0) )
      stop(paste("sigma must be greater than 0", "\n", ""))
    if (any(nu <= 0) )
      stop(paste("nu must be greater than 0", "\n", ""))
    if (any(tau < 0) )
      stop(paste("tau must be greater than 0", "\n", ""))
    if (any(q < 0))
      stop(paste("q must be 0 greater than 0", "\n", ""))
    ly <- max(length(q), length(mu), length(sigma), length(nu),length(tau))
    q <- rep(q, length = ly)
    sigma <- rep(sigma, length = ly)
    mu <- rep(mu, length = ly)
    nu <- rep(nu, length = ly)
    tau <- rep(tau, length = ly)
    cdf <- rep(0, ly)
    cdf <- pGNB_(q,mu,sigma,nu,tau)
    cdf <- ifelse(cdf > 1L, 1L, cdf)
    if (lower.tail == TRUE)
      cdf <- cdf
    else cdf <- 1 - cdf
    if (log.p == FALSE)
      cdf <- cdf
    else cdf <- log(cdf)
    cdf
  }

GNB2=
  function (mu.link = "log", sigma.link = "log", nu.link = "log"){
    mstats <- checklink("mu.link", "GNB2", substitute(mu.link),
                        c("1/mu^2", "log", "identity"))
    dstats <- checklink("sigma.link", "GNB2", substitute(sigma.link),
                        c("1/mu^2", "log", "identity"))
    vstats <- checklink("nu.link", "GNB2", substitute(nu.link),
                        c("1/mu^2", "log", "identity"))
    structure(list(family = c("NBF", "Negative-Binomial-Gamma"),
                   parameters = list(mu = TRUE, sigma = TRUE, nu = TRUE),
                   nopar = 3,
                   type = "Discrete",

                   mu.link    = as.character(substitute(mu.link)),
                   sigma.link = as.character(substitute(sigma.link)),
                   nu.link    = as.character(substitute(nu.link)),

                   mu.linkfun    = mstats$linkfun,
                   sigma.linkfun = dstats$linkfun,
                   nu.linkfun    = vstats$linkfun,

                   mu.linkinv    = mstats$linkinv,
                   sigma.linkinv = dstats$linkinv,
                   nu.linkinv    = vstats$linkinv,

                   mu.dr    = mstats$mu.eta,
                   sigma.dr = dstats$mu.eta,
                   nu.dr    = vstats$mu.eta,

                   #----------------------------------------#
                   # first numerical derivatives            #
                   #----------------------------------------#

                   dldm = function(y, mu, sigma, nu) {
                     lpdf<-function(t,x,sigma,nu){dGNB2(t,x,sigma,nu,log=TRUE)}
                     dldm<-grad(func=lpdf,t=y,x=mu,sigma=sigma,nu=nu,method='simple')
                     dldm
                   },

                   dldd = function(y, mu, sigma, nu) {
                     lpdf<-function(t,mu,x,nu){dGNB2(t,mu,x,nu,log=TRUE)}
                     dldd<-grad(func=lpdf,t=y,mu=mu,x=sigma,nu=nu,method='simple')
                     dldd
                   },

                   dldv = function(y, mu, sigma, nu) {
                     lpdf<-function(t,mu,sigma,x){dGNB2(t,mu,sigma,x,log=TRUE)}
                     dldv<-grad(func=lpdf,t=y,mu=mu,sigma=sigma,x=nu,method='simple')
                     dldv
                   },

                   #----------------------------------------#
                   # second numerical derivatives           #
                   #----------------------------------------#

                   d2ldm2 = function(y, mu, sigma, nu) {
                     lpdf<-function(t,x,sigma,nu){dGNB2(t,x,sigma,nu,log=TRUE)}
                     dldm<-grad(func=lpdf,t=y,x=mu,sigma=sigma,nu=nu,method='simple')
                     d2ldm2 <- -dldm * dldm
                     d2ldm2 <- ifelse(d2ldm2 < -1e-15, d2ldm2,-1e-15)
                     d2ldm2
                   },

                   d2ldd2 = function(y, mu, sigma, nu) {
                     lpdf<-function(t,mu,x,nu){dGNB2(t,mu,x,nu,log=TRUE)}
                     dldd<-grad(func=lpdf,t=y,mu=mu,x=sigma,nu=nu,method='simple')
                     d2ldd2 <- -dldd * dldd
                     d2ldd2 <- ifelse(d2ldd2 < -1e-15, d2ldd2,-1e-15)
                     d2ldd2
                   },

                   d2ldv2 = function(y, mu, sigma, nu) {
                     lpdf<-function(t,mu,sigma,x){dGNB2(t,mu,sigma,x,log=TRUE)}
                     dldv<-grad(func=lpdf,t=y,mu=mu,sigma=sigma,x=nu,method='simple')
                     d2ldv2 <- -dldv * dldv
                     d2ldv2 <- ifelse(d2ldv2 < -1e-15, d2ldv2,-1e-15)
                     d2ldv2
                   },

                   #-----------------------------#
                   # cross numerical derivatives #
                   #-----------------------------#

                   d2ldmdd = function(y, mu, sigma, nu) {
                     lpdf<-function(t,x,sigma,nu){dGNB2(t,x,sigma,nu,log=TRUE)}
                     dldm<-grad(func=lpdf,t=y,x=mu,sigma=sigma,nu=nu,method='simple')
                     lpdf<-function(t,mu,x,nu){dGNB2(t,mu,x,nu,log=TRUE)}
                     dldd<-grad(func=lpdf,t=y,mu=mu,x=sigma,nu=nu,method='simple')
                     d2ldmdd <- -dldm * dldd
                     d2ldmdd <- ifelse(is.na(d2ldmdd)==TRUE,0,d2ldmdd)
                     # d2ldmdd <- ifelse(d2ldmdd < -1e-15, d2ldmdd,-1e-15)
                     d2ldmdd
                   },

                   d2ldmdv = function(y, mu, sigma, nu) {
                     lpdf<-function(t,x,sigma,nu){dGNB2(t,x,sigma,nu,log=TRUE)}
                     dldm<-grad(func=lpdf,t=y,x=mu,sigma=sigma,nu=nu,method='simple')
                     lpdf<-function(t,mu,sigma,x){dGNB2(t,mu,sigma,x,log=TRUE)}
                     dldv<-grad(func=lpdf,t=y,mu=mu,sigma=sigma,x=nu,method='simple')
                     d2ldmdv <- -dldm * dldv
                     d2ldmdv <- ifelse(is.na(d2ldmdv)==TRUE,0,d2ldmdv)
                     # d2ldmdv <- ifelse(d2ldmdv < -1e-15, d2ldmdv,-1e-15)
                     d2ldmdv
                   },

                   d2ldddv = function(y, mu, sigma, nu) {
                     lpdf<-function(t,mu,x,nu){dGNB2(t,mu,x,nu,log=TRUE)}
                     dldd<-grad(func=lpdf,t=y,mu=mu,x=sigma,nu=nu,method='simple')
                     lpdf<-function(t,mu,sigma,x){dGNB2(t,mu,sigma,x,log=TRUE)}
                     dldv<-grad(func=lpdf,t=y,mu=mu,sigma=sigma,x=nu,method='simple')
                     d2ldddv <- -dldd * dldv
                     d2ldddv <- ifelse(is.na(d2ldddv)==TRUE,0,d2ldddv)
                     # d2ldddv <- ifelse(d2ldddv < -1e-15, d2ldddv,-1e-15)
                     d2ldddv
                   },

                   G.dev.incr = function(y, mu, sigma, nu, ...){
                     -2 * dGNB2(y, mu, sigma, nu, log = TRUE)}
                   ,

                   rqres = expression(rqres(pfun = "pGNB2",type = "Discrete",
                                            ymin = 0, y = y, mu = mu, sigma = sigma,
                                            nu = nu)),

                   mu.initial = expression(mu <- (y + mean(y))/2),

                   sigma.initial = expression(sigma <- rep(max(((var(y) - mean(y))/(mean(y)^2)), 0.1), length(y))),

                   nu.initial = expression(nu <- rep(1,length(y))),

                   tau.initial = expression(tau <- rep(1,length(y))),

                   mu.valid = function(mu) all(mu > 0),

                   sigma.valid = function(sigma) all(sigma > 0),

                   nu.valid = function(nu) all(nu > 0 ),

                   y.valid = function(y) all(y >= 0)
    ),

    class = c("gamlss.family","family"))
  }

####################################################
# GNB 0                                            #
####################################################

dGNB0=
  function (x, mu = 1, sigma = 1, nu = 1, log = FALSE){
    tau=0
    if (any(mu <= 0))
      stop(paste("mu must be greater than 0", "\n", ""))
    if (any(sigma <= 0) )
      stop(paste("sigma must be greater than 0", "\n", ""))
    if (any(nu <= 0) )
      stop(paste("nu must be greater than 0", "\n", ""))
    if (any(x < 0))
      stop(paste("x must be 0 or greater than 0", "\n", ""))
    ly <- max(length(x), length(mu), length(sigma), length(nu),length(tau))
    x <- rep(x, length = ly)
    sigma <- rep(sigma, length = ly)
    mu <- rep(mu, length = ly)
    nu <- rep(nu, length = ly)
    tau <- rep(tau, length = ly)
    logfy <- log(dGNB_(x,mu,sigma,nu,tau))
    if (log == FALSE)
      fy <- exp(logfy)
    else fy <- logfy
    fy
  }



pGNB0=
  function (q, mu = 1, sigma = 1, nu = 1,  lower.tail = TRUE,
            log.p = FALSE){
    tau=0
    if (any(mu <= 0))
      stop(paste("mu must be greater than 0", "\n", ""))
    if (any(sigma <= 0) )
      stop(paste("sigma must be greater than 0", "\n", ""))
    if (any(nu <= 0) )
      stop(paste("nu must be greater than 0", "\n", ""))
    if (any(q < 0))
      stop(paste("q must be 0 greater than 0", "\n", ""))
    ly <- max(length(q), length(mu), length(sigma), length(nu),length(tau))
    q <- rep(q, length = ly)
    sigma <- rep(sigma, length = ly)
    mu <- rep(mu, length = ly)
    nu <- rep(nu, length = ly)
    tau <- rep(tau, length = ly)
    cdf <- rep(0, ly)
    cdf <- pGNB_(q,mu,sigma,nu,tau)
    cdf <- ifelse(cdf > 1L, 1L, cdf)
    if (lower.tail == TRUE)
      cdf <- cdf
    else cdf <- 1 - cdf
    if (log.p == FALSE)
      cdf <- cdf
    else cdf <- log(cdf)
    cdf
  }

GNB0=
  function (mu.link = "log", sigma.link = "log", nu.link = "log"){
    mstats <- checklink("mu.link", "GNB2", substitute(mu.link),
                        c("1/mu^2", "log", "identity"))
    dstats <- checklink("sigma.link", "GNB2", substitute(sigma.link),
                        c("1/mu^2", "log", "identity"))
    vstats <- checklink("nu.link", "GNB2", substitute(nu.link),
                        c("1/mu^2", "log", "identity"))
    structure(list(family = c("NBF", "Negative-Binomial-Gamma"),
                   parameters = list(mu = TRUE, sigma = TRUE, nu = TRUE),
                   nopar = 3,
                   type = "Discrete",

                   mu.link    = as.character(substitute(mu.link)),
                   sigma.link = as.character(substitute(sigma.link)),
                   nu.link    = as.character(substitute(nu.link)),

                   mu.linkfun    = mstats$linkfun,
                   sigma.linkfun = dstats$linkfun,
                   nu.linkfun    = vstats$linkfun,

                   mu.linkinv    = mstats$linkinv,
                   sigma.linkinv = dstats$linkinv,
                   nu.linkinv    = vstats$linkinv,

                   mu.dr    = mstats$mu.eta,
                   sigma.dr = dstats$mu.eta,
                   nu.dr    = vstats$mu.eta,

                   #----------------------------------------#
                   # first numerical derivatives            #
                   #----------------------------------------#

                   dldm = function(y, mu, sigma, nu) {
                     lpdf<-function(t,x,sigma,nu){dGNB0(t,x,sigma,nu,log=TRUE)}
                     dldm<-grad(func=lpdf,t=y,x=mu,sigma=sigma,nu=nu,method='simple')
                     dldm
                   },

                   dldd = function(y, mu, sigma, nu) {
                     lpdf<-function(t,mu,x,nu){dGNB0(t,mu,x,nu,log=TRUE)}
                     dldd<-grad(func=lpdf,t=y,mu=mu,x=sigma,nu=nu,method='simple')
                     dldd
                   },

                   dldv = function(y, mu, sigma, nu) {
                     lpdf<-function(t,mu,sigma,x){dGNB0(t,mu,sigma,x,log=TRUE)}
                     dldv<-grad(func=lpdf,t=y,mu=mu,sigma=sigma,x=nu,method='simple')
                     dldv
                   },

                   #----------------------------------------#
                   # second numerical derivatives           #
                   #----------------------------------------#

                   d2ldm2 = function(y, mu, sigma, nu) {
                     lpdf<-function(t,x,sigma,nu){dGNB0(t,x,sigma,nu,log=TRUE)}
                     dldm<-grad(func=lpdf,t=y,x=mu,sigma=sigma,nu=nu,method='simple')
                     d2ldm2 <- -dldm * dldm
                     d2ldm2 <- ifelse(d2ldm2 < -1e-15, d2ldm2,-1e-15)
                     d2ldm2
                   },

                   d2ldd2 = function(y, mu, sigma, nu) {
                     lpdf<-function(t,mu,x,nu){dGNB0(t,mu,x,nu,log=TRUE)}
                     dldd<-grad(func=lpdf,t=y,mu=mu,x=sigma,nu=nu,method='simple')
                     d2ldd2 <- -dldd * dldd
                     d2ldd2 <- ifelse(d2ldd2 < -1e-15, d2ldd2,-1e-15)
                     d2ldd2
                   },

                   d2ldv2 = function(y, mu, sigma, nu) {
                     lpdf<-function(t,mu,sigma,x){dGNB0(t,mu,sigma,x,log=TRUE)}
                     dldv<-grad(func=lpdf,t=y,mu=mu,sigma=sigma,x=nu,method='simple')
                     d2ldv2 <- -dldv * dldv
                     d2ldv2 <- ifelse(d2ldv2 < -1e-15, d2ldv2,-1e-15)
                     d2ldv2
                   },

                   #-----------------------------#
                   # cross numerical derivatives #
                   #-----------------------------#

                   d2ldmdd = function(y, mu, sigma, nu) {
                     lpdf<-function(t,x,sigma,nu){dGNB0(t,x,sigma,nu,log=TRUE)}
                     dldm<-grad(func=lpdf,t=y,x=mu,sigma=sigma,nu=nu,method='simple')
                     lpdf<-function(t,mu,x,nu){dGNB0(t,mu,x,nu,log=TRUE)}
                     dldd<-grad(func=lpdf,t=y,mu=mu,x=sigma,nu=nu,method='simple')
                     d2ldmdd <- -dldm * dldd
                     d2ldmdd <- ifelse(is.na(d2ldmdd)==TRUE,0,d2ldmdd)
                     # d2ldmdd <- ifelse(d2ldmdd < -1e-15, d2ldmdd,-1e-15)
                     d2ldmdd
                   },

                   d2ldmdv = function(y, mu, sigma, nu) {
                     lpdf<-function(t,x,sigma,nu){dGNB0(t,x,sigma,nu,log=TRUE)}
                     dldm<-grad(func=lpdf,t=y,x=mu,sigma=sigma,nu=nu,method='simple')
                     lpdf<-function(t,mu,sigma,x){dGNB0(t,mu,sigma,x,log=TRUE)}
                     dldv<-grad(func=lpdf,t=y,mu=mu,sigma=sigma,x=nu,method='simple')
                     d2ldmdv <- -dldm * dldv
                     d2ldmdv <- ifelse(is.na(d2ldmdv)==TRUE,0,d2ldmdv)
                     # d2ldmdv <- ifelse(d2ldmdv < -1e-15, d2ldmdv,-1e-15)
                     d2ldmdv
                   },

                   d2ldddv = function(y, mu, sigma, nu) {
                     lpdf<-function(t,mu,x,nu){dGNB0(t,mu,x,nu,log=TRUE)}
                     dldd<-grad(func=lpdf,t=y,mu=mu,x=sigma,nu=nu,method='simple')
                     lpdf<-function(t,mu,sigma,x){dGNB0(t,mu,sigma,x,log=TRUE)}
                     dldv<-grad(func=lpdf,t=y,mu=mu,sigma=sigma,x=nu,method='simple')
                     d2ldddv <- -dldd * dldv
                     d2ldddv <- ifelse(is.na(d2ldddv)==TRUE,0,d2ldddv)
                     # d2ldddv <- ifelse(d2ldddv < -1e-15, d2ldddv,-1e-15)
                     d2ldddv
                   },

                   G.dev.incr = function(y, mu, sigma, nu, ...){
                     -2 * dGNB0(y, mu, sigma, nu, log = TRUE)}
                   ,

                   rqres = expression(rqres(pfun = "pGNB0",type = "Discrete",
                                            ymin = 0, y = y, mu = mu, sigma = sigma,
                                            nu = nu)),

                   mu.initial = expression(mu <- (y + mean(y))/2),

                   sigma.initial = expression(sigma <- rep(max(((var(y) - mean(y))/(mean(y)^2)), 0.1), length(y))),

                   nu.initial = expression(nu <- rep(1,length(y))),

                   tau.initial = expression(tau <- rep(1,length(y))),

                   mu.valid = function(mu) all(mu > 0),

                   sigma.valid = function(sigma) all(sigma > 0),

                   nu.valid = function(nu) all(nu > 0 ),

                   y.valid = function(y) all(y >= 0)
    ),

    class = c("gamlss.family","family"))
  }


#include <Rcpp.h>
using namespace Rcpp;

// This is a simple example of exporting a C++ function to R. You can
// source this function into an R session using the Rcpp::sourceCpp
// function (or via the Source button on the editor toolbar). Learn
// more about Rcpp at:
//
//   http://www.rcpp.org/
//   http://adv-r.had.co.nz/Rcpp.html
//   http://gallery.rcpp.org/
//

#define GETV(x, i)      x[i % x.length()]    // wrapped indexing of vector

double cpp_log1pd(double x){
  double a = log(x);
  if(a < -10){
    return 1;
  } else {
    return log1p(x)/x;
  }
}


double cpp_log1pe(double x){
  if(x < 37){
    return log1p(exp(x));
  } else {
    return x;
  }
}

double cpp_log1pde(double x){
  if(x < -20){
    return 1;
  } else {
    return cpp_log1pe(x)/exp(x);
  }
}

double cpp_lpoch_log(double a, int n){
  double x = exp(a);
  if (n == 0){
    return 0;
  } else if(n == 1){
    return a;
  } else if(a < -30){
    return  a+lgamma(n);
  } else if(a > 20){
    return n*a;
  } else {
    return lgamma(x+n)-lgamma(x);
  }

}


double cpp_joint_gnb_prs(double t, int y, double mu, double phi, double nu, double k){
  //double w = exp(z);

  double r = 0;
  //double prob = pow(mu,1-k)/(w+pow(mu,1-k));
  double shape = pow(phi,2-r)/nu;
  double scale = nu/pow(phi,1-r);
  double e = R::digamma(shape)-log(scale);
  double s = sqrt(R::trigamma(shape));
  double z = e+s*t;
  double log_size = (2-k)*log(mu)-z;
  double test = z + (k-1)*log(mu);
  double eval = exp(cpp_lpoch_log(log_size,y)-lgamma(y+1)+y*z+
                    y*(k-1)*log(mu)-y*cpp_log1pe(test)-mu*cpp_log1pde(test)-
                    shape*log(scale)-lgamma(shape)+shape*z-exp(z)/scale+log(s));
  if(R_isnancpp(eval) == TRUE){
    return 0;
  } else {
    return eval;
  }
}


double cpp_joint_gnb_pr(double z, int y, double mu, double phi, double nu, double k){
  //double w = exp(z);
  double log_size = (2-k)*log(mu)-z;
  double r = 0;
  //double prob = pow(mu,1-k)/(w+pow(mu,1-k));
  double shape = pow(phi,2-r)/nu;
  double scale = nu/pow(phi,1-r);
  double test = z + (k-1)*log(mu);
  double eval = exp(cpp_lpoch_log(log_size,y)-lgamma(y+1)+y*z+
                    y*(k-1)*log(mu)-y*cpp_log1pe(test)-mu*cpp_log1pde(test)-
                    shape*log(scale)-lgamma(shape)+shape*z-exp(z)/scale);
  if(R_isnancpp(eval) == TRUE){
    return 0;
  } else {
    return eval;
  }
}

// [[Rcpp::export(rng = false)]]
NumericVector cpp_joint_gnb(
    const NumericVector& z,
    const NumericVector& y,
    const NumericVector& mu,
    const NumericVector& phi,
    const NumericVector& nu,
    const NumericVector& k
) {

  if (std::min({z.length(), y.length(), mu.length(),
               phi.length(), nu.length(),k.length()}) < 1) {
    return NumericVector(0);
  }

  int Nmax = std::max({
    z.length(),
    y.length(),
    mu.length(),
    phi.length(),
    nu.length(),
    k.length()
  });
  NumericVector r(Nmax);

  for (int i = 0; i < Nmax; i++){
    r[i] = cpp_joint_gnb_pr(GETV(z, i), GETV(y, i), GETV(mu, i),
                            GETV(phi, i), GETV(nu, i), GETV(k, i));
  }

  return r;
}

// You can include R code blocks in C++ files processed with sourceCpp
// (useful for testing and development). The R code will be automatically
// run after the compilation.
//

#include <Rcpp.h>
using namespace Rcpp;

// This is a simple function using Rcpp that creates an R list
// containing a character vector and a numeric vector.
//
// Learn more about how to use Rcpp at:
//
//   http://www.rcpp.org/
//   http://adv-r.had.co.nz/Rcpp.html
//
// and browse examples of code using Rcpp at:
//
//   http://gallery.rcpp.org/
//

#define GETV(x, i)      x[i % x.length()]    // wrapped indexing of vector


double cpp_log1pexp(double x){
  if (x <= -37) {
    return exp(x);
  } else if (x <= 18) {
    return log1p(exp(x));
  } else if (x <= 33.3) {
    return x + exp(-x);
  } else{
    return x;
  }
}


double cpp_lpoch_(double m, double w, int n){
  if (n == 0){
    return 0;
  } else if(n == 1){
    return log(m)-w;
  } else {
    double result = log(m)-w;
    for (int i = 2; i <= n; ++i) {
      result += log(i - 1) + cpp_log1pexp(-w+log(m)-log(i-1));
    }
    return result;
  }

}


double cpp_lpoch(double m, double w, int n){
  double a = log(m)-w;
  if (n == 0){
    return 0;
  } else if(n == 1){
    return a;
  } else if(a < -30){
    return  a+lgamma(n);
  } else if(a > 20){
    return n*a;
  } else {
    return lgamma(exp(a)+n)-lgamma(exp(a));
  }

}


double cpp_dlbb(int y, int n, double m, double w){
  return R::lchoose(n,y)+cpp_lpoch(m,w,y)+cpp_lpoch(1-m,w,n-y)-cpp_lpoch(1,w,n);
}


double cpp_dlgl(double y, double a, double b){
  return a*y - (a+b)*cpp_log1pexp(y) -lgamma(a) - lgamma(b) + lgamma(a+b);
}


double cpp_joint(double w, int y,int n, double m, double d, double v){
  return exp(cpp_dlbb(y,n,m,w)+cpp_dlgl(w,d*(1-v)/v,(1-d)*(1-v)/v));
}

double cpp_joint_sd(double z, int y,int n, double m, double d, double v){
  double e = R::digamma(d*(1-v)/v)-R::digamma((1-d)*(1-v)/v);
  double s = sqrt(R::trigamma(d*(1-v)/v)+R::trigamma((1-d)*(1-v)/v));
  double w = e+s*z;
  return exp(cpp_dlbb(y,n,m,w)+cpp_dlgl(w,d*(1-v)/v,(1-d)*(1-v)/v)+log(s));
}



NumericVector cpp_joint_(
    const NumericVector& w,
    const NumericVector& y,
    const NumericVector& n,
    const NumericVector& m,
    const NumericVector& d,
    const NumericVector& v
) {

  if (std::min({w.length(), y.length(), n.length(),
               m.length(), d.length(),v.length()}) < 1) {
    return NumericVector(0);
  }

  int Nmax = std::max({
    w.length(),
    y.length(),
    n.length(),
    m.length(),
    d.length(),
    v.length()
  });
  NumericVector r(Nmax);

  for (int i = 0; i < Nmax; i++){
    r[i] = cpp_joint(GETV(w, i), GETV(y, i), GETV(n, i),
                     GETV(m, i), GETV(d, i), GETV(v, i));
  }

  return r;
}

// [[Rcpp::export(rng = false)]]
NumericVector cpp_joint_sd_(
    const NumericVector& z,
    const NumericVector& y,
    const NumericVector& n,
    const NumericVector& m,
    const NumericVector& d,
    const NumericVector& v
) {

  if (std::min({z.length(), y.length(), n.length(),
               m.length(), d.length(),v.length()}) < 1) {
    return NumericVector(0);
  }

  int Nmax = std::max({
    z.length(),
    y.length(),
    n.length(),
    m.length(),
    d.length(),
    v.length()
  });
  NumericVector r(Nmax);

  for (int i = 0; i < Nmax; i++){
    r[i] = cpp_joint_sd(GETV(z, i), GETV(y, i), GETV(n, i),
                        GETV(m, i), GETV(d, i), GETV(v, i));
  }

  return r;
}


// You can include R code blocks in C++ files processed with sourceCpp
// (useful for testing and development). The R code will be automatically
// run after the compilation.
//



pB2B.scalar = function(y,n,mu,delta,nu){
  sum(dB2B.(0:y,n,mu,delta,nu))
}

pB2B. = Vectorize(pB2B.scalar)

pB2B=
  function (q, mu = 0.5, sigma = 0.5, nu = 0.1, bd = 1, lower.tail = TRUE,
            log.p = FALSE){
    if (any(mu <= 0) | any(mu >= 1))
      stop(paste("mu must be between 0 and 1", "\n", ""))
    if (any(nu <= 0) | any(nu >= 1))
      stop(paste("nu must be between 0 and 1", "\n", ""))
    if (any(sigma <= 0) | any(sigma >= 1))
      stop(paste("sigma must be between 0 and 1", "\n", ""))
    if (any(q < 0))
      stop(paste("y must be 0 or greater than 0", "\n", ""))
    if (any(bd < q))
      stop(paste("y  must be <=  than the binomial denominator",
                 bd, "\n"))
    ly <- max(length(q), length(mu), length(sigma), length(nu),
              length(bd))
    q <- rep(q, length = ly)
    sigma <- rep(sigma, length = ly)
    mu <- rep(mu, length = ly)
    nu <- rep(nu, length = ly)
    bd <- rep(bd, length = ly)
    cdf <- rep(0, ly)
    cdf <- pB2B.(q,bd,mu,sigma,nu)
    cdf <- ifelse(cdf > 1L, 1L, cdf)
    if (lower.tail == TRUE)
      cdf <- cdf
    else cdf <- 1 - cdf
    if (log.p == FALSE)
      cdf <- cdf
    else cdf <- log(cdf)
    cdf
  }

B2B=
  function (mu.link = "logit", sigma.link = "logit", nu.link = "logit"){
    mstats <- checklink("mu.link", "B2B", substitute(mu.link),
                        c("logit", "probit", "cloglog", "cauchit", "log", "own"))
    dstats <- checklink("sigma.link", "B2B", substitute(sigma.link),
                        c("logit", "probit", "cloglog", "cauchit", "log", "own"))
    vstats <- checklink("nu.link", "B2B", substitute(nu.link),
                        c("logit", "probit", "cloglog", "cauchit", "log", "own"))
    structure(list(family = c("BB", "Beta-2-Binomial"),
                   parameters = list(mu = TRUE, sigma = TRUE, nu = TRUE),
                   nopar = 3,
                   type = "Discrete",

                   mu.link = as.character(substitute(mu.link)),
                   sigma.link = as.character(substitute(sigma.link)),
                   nu.link = as.character(substitute(nu.link)),

                   mu.linkfun = mstats$linkfun,
                   sigma.linkfun = dstats$linkfun,
                   nu.linkfun = vstats$linkfun,

                   mu.linkinv = mstats$linkinv,
                   sigma.linkinv = dstats$linkinv,
                   nu.linkinv = vstats$linkinv,

                   mu.dr = mstats$mu.eta,
                   sigma.dr = dstats$mu.eta,
                   nu.dr = vstats$mu.eta,

                   #----------------------------------------#
                   # first numerical derivatives            #
                   #----------------------------------------#

                   dldm = function(y, mu, sigma, nu, bd) {
                     lpdf<-function(t,x,sigma,nu,bd){log.dB2B.(t,bd,x,sigma,nu)}
                     dldm<-grad(func=lpdf,t=y,x=mu,sigma=sigma,nu=nu,bd=bd,method='simple')
                     dldm
                   },

                   dldd = function(y, mu, sigma, nu, bd) {
                     lpdf<-function(t,mu,x,nu,bd){log.dB2B.(t,bd,mu,x,nu)}
                     dldd<-grad(func=lpdf,t=y,mu=mu,x=sigma,nu=nu,bd=bd,method='simple')
                     dldd
                   },

                   dldv = function(y, mu, sigma, nu, bd) {
                     lpdf<-function(t,mu,sigma,x,bd){log.dB2B.(t,bd,mu,sigma,x)}
                     dldv<-grad(func=lpdf,t=y,mu=mu,sigma=sigma,x=nu,bd=bd,method='simple')
                     dldv
                   },

                   #----------------------------------------#
                   # second numerical derivatives           #
                   #----------------------------------------#

                   d2ldm2 = function(y, mu, sigma, nu, bd) {
                     lpdf<-function(t,x,sigma,nu,bd){log.dB2B.(t,bd,x,sigma,nu)}
                     dldm<-grad(func=lpdf,t=y,x=mu,sigma=sigma,nu=nu,bd=bd,method='simple')
                     d2ldm2 <- -dldm * dldm
                     d2ldm2 <- ifelse(d2ldm2 < -1e-15, d2ldm2,-1e-15)
                     d2ldm2
                   },

                   d2ldd2 = function(y, mu, sigma, nu, bd) {
                     lpdf<-function(t,mu,x,nu,bd){log.dB2B.(t,bd,mu,x,nu)}
                     dldd<-grad(func=lpdf,t=y,mu=mu,x=sigma,nu=nu,bd=bd,method='simple')
                     d2ldd2 <- -dldd * dldd
                     d2ldd2 <- ifelse(d2ldd2 < -1e-15, d2ldd2,-1e-15)
                     d2ldd2
                   },

                   d2ldv2 = function(y, mu, sigma, nu, bd) {
                     lpdf<-function(t,mu,sigma,x,bd){log.dB2B.(t,bd,mu,sigma,x)}
                     dldv<-grad(func=lpdf,t=y,mu=mu,sigma=sigma,x=nu,bd=bd,method='simple')
                     d2ldv2 <- -dldv * dldv
                     d2ldv2 <- ifelse(d2ldv2 < -1e-15, d2ldv2,-1e-15)
                     d2ldv2
                   },

                   #-----------------------------#
                   # cross numerical derivatives #
                   #-----------------------------#

                   d2ldmdd = function(y, mu, sigma, nu, bd) {
                     lpdf<-function(t,x,sigma,nu,bd){log.dB2B.(t,bd,x,sigma,nu)}
                     dldm<-grad(func=lpdf,t=y,x=mu,sigma=sigma,nu=nu,bd=bd,method='simple')
                     lpdf<-function(t,mu,x,nu,bd){log.dB2B.(t,bd,mu,x,nu)}
                     dldd<-grad(func=lpdf,t=y,mu=mu,x=sigma,nu=nu,bd=bd,method='simple')
                     d2ldmdd <- -dldm * dldd
                     d2ldmdd <- ifelse(is.na(d2ldmdd)==TRUE,0,d2ldmdd)
                     d2ldmdd
                   },

                   d2ldmdv = function(y, mu, sigma, nu, bd) {
                     lpdf<-function(t,x,sigma,nu,bd){log.dB2B.(t,bd,x,sigma,nu)}
                     dldm<-grad(func=lpdf,t=y,x=mu,sigma=sigma,nu=nu,bd=bd,method='simple')
                     lpdf<-function(t,mu,sigma,x,bd){log.dB2B.(t,bd,mu,sigma,x)}
                     dldv<-grad(func=lpdf,t=y,mu=mu,sigma=sigma,x=nu,bd=bd,method='simple')
                     d2ldmdv <- -dldm * dldv
                     d2ldmdv
                   },

                   d2ldddv = function(y, mu, sigma, nu, bd) {
                     lpdf<-function(t,mu,x,nu,bd){log.dB2B.(t,bd,mu,x,nu)}
                     dldd<-grad(func=lpdf,t=y,mu=mu,x=sigma,nu=nu,bd=bd,method='simple')
                     lpdf<-function(t,mu,sigma,x,bd){log.dB2B.(t,bd,mu,sigma,x)}
                     dldv<-grad(func=lpdf,t=y,mu=mu,sigma=sigma,x=nu,bd=bd,method='simple')
                     d2ldddv <- -dldd * dldv
                     d2ldddv
                   },

                   G.dev.incr = function(y, mu, sigma, nu, bd, ...){
                     -2 * dB2B(y, mu, sigma, nu, bd, log = TRUE)}
                   ,

                   rqres = expression(rqres(pfun = "pB2B",type = "Discrete",
                                            ymin = 0, y = y, mu = mu, sigma = sigma,
                                            nu = nu, bd = bd)),

                   mu.initial = expression(mu <- rep(0.5,length(y))),

                   sigma.initial = expression(sigma <- rep(0.5,length(y))),

                   nu.initial = expression(nu <- rep(0.3,length(y))),

                   mu.valid = function(mu) all(mu > 0 & mu < 1),

                   sigma.valid = function(sigma) all(sigma > 0 & sigma < 1),

                   nu.valid = function(nu) all(nu > 0 & nu < 1),

                   y.valid = function(y) all(y >= 0)
    ),

    class = c("gamlss.family","family"))
  }

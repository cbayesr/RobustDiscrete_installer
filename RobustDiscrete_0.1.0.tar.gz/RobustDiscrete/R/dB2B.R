

dB2B.scalar = function(y,n,mu,delta,nu){
  if(delta < 1e-10){
    return(dbinom(y,n,mu))
  } else{
    r = integrate(cpp_joint_sd_,-Inf,Inf,y=y,n=n,m=mu,d=delta,v=nu,
                  stop.on.error = FALSE,rel.tol = 1e-8)
    if(r$message=="OK"){
      return(r$value)
    }
    else{
      return(integrate(cpp_joint_sd_,-Inf,Inf,y=y,n=n,m=mu,d=delta,v=nu,
                       rel.tol = 1e-8,stop.on.error = FALSE,
                       subdivisions = 1000)$value)
    }
  }
}



dB2B. = Vectorize(dB2B.scalar)

log.dB2B.scalar = function(y,n,mu,delta,nu){
  if(nu<1e-6){
    return(dBB(y,mu,delta/(1-delta),n,log=TRUE))
  }
  if(nu>1-1e-5){
    if((y>0)&(y<n)){
      return(log1p(delta)+dbinom(y,n,mu,log=TRUE))
    }
    if(y==0){return(log(delta*(1-mu)+(1-delta)*(1-mu)**n))}
    if(y==n){return(log(delta*mu+(1-delta)*mu**n))}
  }
  if(delta<1e-4){
    return(dbinom(y,n,mu,log=TRUE))
  }
  if(delta>1-1e-10){
    return(log(dB2B.(y,n,mu,1-1e-10,nu)))
  }
  return(log(dB2B.(y,n,mu,delta,nu)))
}


log.dB2B. = Vectorize(log.dB2B.scalar)


dB2B=
  function (x, mu = 0.5, sigma = 0.1, nu = 0.1, bd = 1, log = FALSE){
    if (any(mu <= 0) | any(mu >= 1))
      stop(paste("mu must be between 0 and 1", "\n", ""))
    if (any(sigma <= 0) | any(sigma >= 1))
      stop(paste("sigma must be between 0 and 1", "\n", ""))
    if (any(nu <= 0) | any(nu >= 1))
      stop(paste("nu must be between 0 and 1", "\n", ""))
    if (any(x < 0))
      stop(paste("x must be 0 or greater than 0", "\n", ""))
    if (any(bd < x))
      stop(paste("x  must be <=  than the binomial denominator",
                 bd, "\n"))
    ly <- max(length(x), length(mu), length(sigma), length(bd))
    x <- rep(x, length = ly)
    sigma <- rep(sigma, length = ly)
    mu <- rep(mu, length = ly)
    nu <- rep(nu, length = ly)
    bd <- rep(bd, length = ly)
    logfy <- log.dB2B.(x,bd,mu,sigma,nu)
    if (log == FALSE)
      fy <- exp(logfy)
    else fy <- logfy
    fy
  }

